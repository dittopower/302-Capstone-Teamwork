<?php
require_once "$_SERVER[DOCUMENT_ROOT]/lib.php";
lib_chat();
?>