<?php
	require_once "../lib.php";
	lib_register();
	reg_form();
?>